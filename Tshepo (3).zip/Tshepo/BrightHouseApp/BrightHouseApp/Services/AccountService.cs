﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using BrightHouseApp.Models;
using MongoDB.Driver;

namespace BrightHouseApp.Services
{
    public class AccountService
    {
        private readonly IMongoCollection<Admins> admins;

        public AccountService(IConfiguration config)
        {
            MongoClient client = new MongoClient(config.GetConnectionString("Britehousedb"));
            IMongoDatabase database = client.GetDatabase("Britehousedb");
            admins = database.GetCollection<Admins>("Admins");
        }

        public List<Admins> Get()
        {
            return admins.Find(admin => true).ToList();
        }

        public Admins Get(string id)
        {
            return admins.Find(admin => admin.Id == id).FirstOrDefault();
        }

        public Admins Create(Admins admin)
        {
            admins.InsertOne(admin);
            return admin;
        }

        public void Update(string id, Admins adminIn)
        {
            admins.ReplaceOne(admin => admin.Id == id, adminIn);
        }

        public void Remove(Admins adminIn)
        {
            admins.DeleteOne(admin => admin.Id == adminIn.Id);
        }

        public void Remove(string id)
        {
            admins.DeleteOne(admin => admin.Id == id);
        }
    }
}

    

