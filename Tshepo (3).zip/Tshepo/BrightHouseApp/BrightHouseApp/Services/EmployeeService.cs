﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using BrightHouseApp.Models;
using MongoDB.Driver;
namespace BrightHouseApp.Services
{
    public class EmployeeService
    {
        private readonly IMongoCollection<Employee> employee;

        public EmployeeService(IConfiguration config)
        {
            MongoClient client = new MongoClient(config.GetConnectionString("Britehousedb"));
            IMongoDatabase database = client.GetDatabase("Britehousedb");
            employee = database.GetCollection<Employee>("Employee");
        }

        public List<Employee> Get()
        {
            return employee.Find(_employee => true).ToList();
        }

        public Employee Get(int id)
        {
            return employee.Find(_employee => _employee.EmployeeNumber == id).FirstOrDefault();
        }

        public Employee Create(Employee _employee)
        {
           employee.InsertOne(_employee);
            return _employee;
        }

        public void Update(int id, Employee employeeIn)
        {
            employee.ReplaceOne(_employee => _employee.EmployeeNumber == id, employeeIn);
        }

        public void Remove(Employee employeeIn)
        {
            employee.DeleteOne(_employee => _employee.EmployeeNumber == employeeIn.EmployeeNumber);
        }

        public void Remove(int id)
        {
            employee.DeleteOne(_employee => _employee.EmployeeNumber == id);
        }
    }
}
