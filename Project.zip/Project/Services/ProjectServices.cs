﻿using System;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using Project.Models;
using System.Threading.Tasks;
using Project.Services;


namespace Project.Services
{
    public class ProjectServices { 
    
            private readonly IMongoCollection<DimensionData> projects;

            public ProjectServices(IConfiguration config)
            {
                MongoClient client = new MongoClient(config.GetConnectionString("Project"));
                IMongoDatabase database = client.GetDatabase("Project");
                projects = database.GetCollection<DimensionData>("Projects");
            }

            public List<DimensionData> Get()
            {
                return projects.Find(project => true).ToList();
            }

            public DimensionData Get(string id)
            {
                return projects.Find(project => project.EmployeeNumber == id).FirstOrDefault();
            }

            public DimensionData Create(DimensionData project)
            {
                projects.InsertOne(project);
                return project;
            }

            public void Update(string id, DimensionData projectIn)
            {
                projects.ReplaceOne(project => project.EmployeeNumber == id, projectIn);
            }

            public void Remove(DimensionData projectIn)
            {
                projects.DeleteOne(peoject => projectIn.EmployeeNumber == projectIn.EmployeeNumber);
            }

            public void Remove(string id)
            {
                projects.DeleteOne(project => project.EmployeeNumber == id);
            }
        }
    }

