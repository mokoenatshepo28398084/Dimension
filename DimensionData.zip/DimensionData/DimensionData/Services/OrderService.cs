﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using DimensionData.Models;

namespace DimensionData.Services
{
    public class OrderService
    {
        private readonly IMongoCollection<Orders> orders;

        public OrderService(IConfiguration config)
        {
            // MongoClient client = new MongoClient(config.GetConnectionString("GlobalStore"));
            MongoClient client = new MongoClient(config.GetConnectionString("dimensiondb"));
            IMongoDatabase database = client.GetDatabase("dimensiondb");
            orders = database.GetCollection<Orders>("Orders");
        }

        public List<Orders> Get()
        {
            return orders.Find(order => true).ToList();
        }

        public Orders Get(string id)
        {
            return orders.Find(order => order.EmployeeNumber == id).FirstOrDefault();
        }

        public Orders Create(Orders order)
        {
            orders.InsertOne(order);
            return order;
        }

        public void Update(string id, Orders orderIn)
        {
            orders.ReplaceOne(order => order.EmployeeNumber == id, orderIn);
        }

        public void Remove(Orders orderIn)
        {
            orders.DeleteOne(order => order.EmployeeNumber == orderIn.EmployeeNumber);
        }

        public void Remove(string id)
        {
            orders.DeleteOne(order => order.EmployeeNumber == id);
        }
    }
}
