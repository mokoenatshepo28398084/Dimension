﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project.Data;
using Project.Models;
using Project.Services;


namespace Project.Controllers
{
    public class ProjectController : Controller
    {
            private readonly ProjectServices projectService;

            public ProjectController(ProjectServices projectService)
        {
                this.projectService = projectService;
            }
            // GET: Order
            public ActionResult Index()
            {
                return View(projectService.Get());
            }

            // GET: Order/Details/5
            public ActionResult Details(int id)
            {
                return View();
            }

            // GET: Order/Create
            public ActionResult Create()
            {
                return View();
            }

            // POST: Order/Create
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Create(IFormCollection collection)
            {
                try
                {
                    // TODO: Add insert logic here

                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }

            // GET: Order/Edit/5
            public ActionResult Edit(int id)
            {
                return View();
            }

            // POST: Order/Edit/5
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Edit(int id, IFormCollection collection)
            {
                try
                {
                    // TODO: Add update logic here

                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }

            // GET: Order/Delete/5
            public ActionResult Delete(int id)
            {
                return View();
            }

            // POST: Order/Delete/5
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Delete(int id, IFormCollection collection)
            {
                try
                {
                    // TODO: Add delete logic here

                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }
        }
}
